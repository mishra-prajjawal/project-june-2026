# FoodConnect — AI Coding Agent Build Kit

This kit tells an AI coding agent (Antigravity / Gemini 3.5 Flash — High) exactly how to build **FoodConnect** end-to-end, locally, completely, and well-tested — **skipping nothing**.

## How to use it
1. Open your coding agent and attach all of these files to the workspace so they stay in context.
2. Paste `00_PROMPT.md` as your first message.
3. Make the agent confirm understanding + show the folder structure + Phase 1 plan before it scaffolds.
4. Run the loop in `BUILD_PLAYBOOK.md`: **Build → Battle-test → Optimize → repeat** until you say "satisfied."

## Files
| File | Purpose |
|---|---|
| `00_PROMPT.md` | The kickoff prompt to paste into the agent. |
| `AGENTS.md` | The hard rules / engineering charter. The agent must never break these. |
| `PROJECT_SPEC.md` | The complete, authoritative scope. Everything here ships. |
| `BUILD_PLAYBOOK.md` | The 3-phase doctrine, testing bar, and Definition of Done. |
| `STYLE_GUIDE.md` | Human-style code + comments, and the non-negotiable UI/UX bar. |
| `PROGRESS.md` | Live checklist the agent ticks as it completes spec items. |

## The one rule that matters most
> If it's in `PROJECT_SPEC.md` sections 1–12, it gets built, wired to events, made beautiful, tested, and ticked off. If it's in section 13, it's explicitly future scope. There is no third option, and nothing gets silently dropped.

## Fixed stack
Python 3.12+ / Django · Aiven MySQL · Tailwind CSS + thin custom CSS · custom event-driven, reactive backend (signal event bus + SSE/WebSocket live push) · runs fully on localhost.

License of the product being built: Apache 2.0 (author: Prajjawal Mishra).
