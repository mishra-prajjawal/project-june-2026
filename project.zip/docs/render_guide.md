# Render Deployment Guide — FoodConnect

This document describes how to deploy the **FoodConnect** application to **Render** using the Docker container runtime.

---

## 1. Prerequisites
- A Render account (free tier is fully supported).
- A GitHub repository containing the codebase.

---

## 2. Deployment Steps

### Step 2.1: Create a New Web Service
1. Log in to the [Render Dashboard](https://dashboard.render.com/).
2. Click **New +** in the top-right and select **Web Service**.
3. Connect your GitHub account and choose the `project-june-2026` repository.

### Step 2.2: Configure Build Settings
- **Name**: `foodconnect` (or any custom name).
- **Region**: Select a region close to your target users (e.g., Oregon, Frankfurt).
- **Branch**: `main` (or your active release branch).
- **Runtime**: **Docker** (Render will automatically detect the `Dockerfile` at the root and build it using multi-stage compilation).

### Step 2.3: Choose Plan
- Select the **Free** instance type (256MB RAM, 0.15 vCPU).

---

## 3. Configure Environment Variables
Under the **Environment** tab, click **Add Environment Variable** and register the following:

| Key | Value | Description |
|---|---|---|
| `DEBUG` | `False` | Disables debug mode for secure production runs. |
| `SECRET_KEY` | `your-long-secure-random-secret-key` | Django cryptographic signing key. |
| `ALLOWED_HOSTS` | `foodconnect.onrender.com,localhost,127.0.0.1` | Set this to your actual Render subdomain URL. |
| `DATABASE_URL` | `sqlite:///db.sqlite3` | Local SQLite fallback (or swappable with MySQL/PostgreSQL). |

---

## 4. Ephemeral Database Recovery & Seeding
Because Render's free tier uses ephemeral storage:
- SQLite databases are reset to zero when the instance restarts (on deployments, inactivity, or standard daily cycles).
- **Auto-Recovery**: Our Docker configuration includes an entrypoint that runs migrations (`migrate`) and seeds test user data (`seed_data`) on container boot.
- If a restart clears the SQLite file, Gunicorn starts by instantly rebuilding the SQLite database, meaning the application is **always** in a ready-to-use demo state with default users (`admin`, `donor1`, `ngo1`, `ngo2` with password `password`).
